function [xstar, fmin] = RCLAD(y,d,x,bstart)

%function [xstar, fmin] = RCLAD(y,d,x)
%RCLAD estimates a randomly censored median regresion model
%using the procedure in Honore, Khan, Powell (2002)
%y - dependent variable
%d - (right) censoring indicator d = 1(y^* < c), i.e. 1 if not censored
%x - independent variables
%bstart - vector/matrix of starting points for optimization
%Copyright: Arkadiusz Szydlowski

K = size(x,2);
nstart = size(bstart,1);

if size(bstart,2) ~= K
   error('Number of columns in bstart should match the number of columns in x.')
end

xstar = zeros(nstart,K);
fval = zeros(nstart,1);

for i = 1:nstart
  [xstar(i,:),fval(i)] = fminsearch(@(b) RCLADobj(b,y,d,x), bstart(i,:));
end

[fmin,imin] = min(fval);
xstar = xstar(imin,:); 
