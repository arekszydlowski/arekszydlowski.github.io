function thhat = FTW(Y,X,wopt) 

% function thhat = FTW(Y,X,wopt) 
% implements Foster, Tian, Wei (01) estimator of the semiparametric Box-Cox model
% wopt - weight function option
%        wopt = 0 normal
%        wopt = 1 logistic        

%Calculate starting value from OLS
%Copyright: Arkadiusz Szydlowski

[Ytransf,gstart] = boxcox(Y);
bstart = X'*Ytransf/(X'*X);
if ~isfinite(bstart); bstart = ones(size(X,2),1); end
pstart = [gstart.*(gstart>-5 & gstart <5); bstart.*(bstart>-5 & bstart<5)]; 

options = optimset('Display','off');

thhat = fmincon(@(par) FTW_obj(Y,X*par(2:end),wopt,mean(Y),std(Y),par(1)), ...
    pstart,[],[],[],[],-5*ones(size(pstart)),5*ones(size(pstart)), ...
    @(par) FTWcons(Y,X,par),options);

