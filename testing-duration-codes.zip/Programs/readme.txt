Contents: This is a README file for the programs used in Szydlowski (2017), 'Testing a parametric transformation model versus a
nonparametric alternative'. 

Date: 4 July 2017.

Please email me if you find any errors.

The following main files are included:

1. mcsim_CSbootbsparb.m 
Performs simulations for the linear transformation model in the null using parametric bootstrap.
Dependencies:
	(a) chen02_sorted.m 
	Estimates transformation function at point y nonparametrically using Chen (2002).
	Dependencies: 
		      (i) chen02_sortobj.m
		      Calculates objective function for Chen's estimator.

2. mcsim_CScensbootbs.m
Performs simulations for the linear transformation model in the null, under random censoring, using nonparametric bootstrap.
Dependencies:
	(a) KaplanMeier.m
	Kaplan-Meier estimator for the censoring distribution
	(b) RCLAD.m
	Estimates a randomly censored median regresion model using the procedure in Honore, Khan, Powell (2002).
	Dependencies:
		(i) RCLADobj.m
		Calculates objective function for RCLAD estimator.
	(c) chen02cens_sorted.m
	Estimates transformation function at point y nonparametrically using Chen (2002) under random censoring.
		  (i) chen02cens_sortobj.m
		  Calculates objective function for Chen's estimator under random censoring.
		  Dependencies:
			- KaplanMeier.m
			...
		  
3. mcsim_CSbootbparbBC.m
Performs simulations for the Box-Cox transformation model in the null using parametric bootstrap.
Dependencies:
	(a) FTW.m
	Implements Foster, Tian, Wei (2001) estimator of the semiparametric Box-Cox model.
	Dependencies:
		(i) FTW_obj.mexa64
		Objective function for the FTW estimator. Compiled using mex function in MATLAB. This file needs to be 
		recompiled from the source .cpp file before running the simulations.
		Dependencies:
			  - FTW_obj.cpp
			  Source C++ file for FTW_obj.mexa64.
		(ii) FTWcons.m
		Calculates the constraint for the FTW problem.
	(b) chen02_sorted.m 
	...

4. mcsim_CSbootbs.m 
Performs simulations for the linear transformation model in the null using nonparametric bootstrap (not reported in the paper).
...

5. mcsim_CSbootbBC.m
Performs simulations for the Box-Cox transformation model in the null using nonparametric bootstrap (not reported in the paper).
...
