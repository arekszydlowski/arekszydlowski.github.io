function lhat = chen02_sorted(y,Y,X,y0,ystart) 

%Copyright: Arkadiusz Szydlowski
p=length(y);
lhat=zeros(size(y));

for k=1:p
  lhat(k)=fminsearch(@(l) -chen02_sortobj(Y,X,y(k),y0,l),ystart(k));
end
