function Gamma  = chen02_sortobj(Y,X,s,y0,l) 

%Copyright: Arkadiusz Szydlowski

n = length(Y);
Zstar = [X; X+l];
[Zstar,t] = sort(Zstar);
Dstar = [(Y>=s); (Y>=y0)];
Dstar = Dstar(t);
Gamma = [1:2*n]*Dstar;
