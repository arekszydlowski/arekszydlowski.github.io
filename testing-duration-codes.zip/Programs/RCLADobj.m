function fobj = RCLADobj(b,y,d,x)

%function fobj = RCLADobj(b,y,d,x)
%Copyright: Arkadiusz Szydlowski

% Calculate KM estimator of the CDF of C
[KM,csup] = ecdf(y,'censoring',d);
csup = csup(2:end)';
n = length(y);
nsup = length(csup);
% Calculate probabilities for the sample values of C 
Prob = diff(KM);

fobj = mean(d.*((abs(y(:,ones(1,nsup)) - min(repmat(x*b',1,nsup),csup(ones(n,1),:))))*Prob)+(1-d).*(abs(y-min(x*b',y))));
