function lhat = chen02cens_sorted(y,Y,X,D,y0,G0,ystart) 

%Copyright: Arkadiusz Szydlowski

p=length(y);
lhat=zeros(size(y));

for k=1:p
  lhat(k)=fminsearch(@(l) -chen02cens_sortobj(Y,X,D,y(k),y0,G0,l),ystart(k));
end
