function mcsim_CScensbootbs(batch,mc,n,range,qopt,nq,opt,uopt,brep)

% MC simulations with bootstrap critical value
% mc - # of MC simulations
% n - sample size
% range - defines the range of y values: [-range, range]; range = 2 or 3
% qopt - integration option
%     qopt=0 MATLAB quad
%     qopt=1 MC integration
%     qopt=2 MATLAB integral
% opt - test option
%     opt=0 true model: T(y)=y
%     opt=1 true model: T(y)=log(y+b)-log(b)
%     opt=2 true model: T(y)=1/13 sinh(2y) 
% uopt - error distribution option
%     uopt=0 normal(0,1) 
%     uopt=1 extreme value type 1 (Cox model) 
%     uopt=2 logistic (MPH model with extreme value type I unobserved heterogeneity)
% nq - number of points in MC integration 
%Copyright: Arkadiusz Szydlowski
%
%if (ischar(batch)), batch=str2num(batch); end;
%if (ischar(mc)), mc=str2num(mc); end;
%if (ischar(n)), n=str2num(n); end;
%if (ischar(range)), range=str2num(range); end;
%if (ischar(qopt)), qopt=str2num(qopt); end;
%if (ischar(nq)), nq=str2num(nq); end;
%if (ischar(opt)), opt=str2num(opt); end;
%if (ischar(uopt)), uopt=str2num(uopt); end;
%if (ischar(brep)), brep=str2num(brep); end;

seedname=sprintf('seedCS%d_%d.mat',n,batch);
if exist(seedname,'file')~=0
  load(seedname);
else
  rng('shuffle');
  seed = rng;
  name = sprintf('seedCS%d_%d.mat',n,batch);
  save(name,'seed');
end

y0 = 0; %normalization point

if range==2
  b = 2.1167;
elseif range==3
  b = 3.0267;
end 

TCSb = zeros(1,brep);
Tres = zeros(mc,3);
time = zeros(mc,1);

%drawing points for MC integration
rng('default');
u=-range+2*range*rand(nq,1);

for i=1:mc
  rng(seed); 
  tic;
  Z=randn(n,1);
  if uopt==0
      U=randn(n,1);
  elseif uopt==1
      U=evrnd(0,1,[n 1]);
  elseif uopt==1.5
      U=evrnd(0,1,[n 1])-log(log(2));
  elseif uopt==2
      unif = rand(n,1);
      U = log(unif./(1-unif));
  end
  if opt==0
      Y = Z + U;
      mu = 1.46*(uopt==0)+1.02*(uopt==1)+1.87*(uopt==2)+1.39*(uopt==1.5);
  elseif opt==1
      Y = b*exp(Z + U) - b;
      mu = 4.96*(uopt==0)+2.63*(uopt==1)+9.04*(uopt==2)+4.63*(uopt==1.5);
  elseif opt==2
      Y = 0.5*asinh(13*(Z+U));
      mu = 1.81*(uopt==0)+1.4*(uopt==1)+1.97*(uopt==2)+1.77*(uopt==1.5);
  elseif opt==10
      Y = 2*Z + U;
      mu = 2.07*(uopt==0)+1.57*(uopt==1)+2.4*(uopt==2)+1.97*(uopt==1.5);
  end

  %censoring
  C = mu + randn(n,1);
  D = (Y<=C);
  Y = min(Y,C);

  %calculate G(y_0) and G(y)
  [Ys,t] = sort(Y);
  Ds = D(t);
  Zs = Z(t);
  G0 = KaplanMeier(y0,Ys,Ds);
  if G0<1e-6; G0 = 1e-6; end;
  
  bhat = RCLAD(Y,D,Z,Z'*Y/(Z'*Z));
  
  if qopt==0
    TCS = quad(@(u) (bhat*chen02cens_sorted(u,Ys,Zs,Ds,y0,G0,u)-u).^2,-range,range,1e-3);
  elseif qopt==1
    Lhat = bhat*chen02cens_sorted(u,Ys,Zs,Ds,y0,G0,u);
    TCS = mean((Lhat-u).^2)*2*range;
  elseif qopt==2
    TCS = integral(@(u) (bhat*chen02cens_sorted(u,Ys,Zs,Ds,y0,G0,u)-u).^2,-range,range,'AbsTol',1e-3);
  end
  seed = rng; %store seed for generating next MC draws
  		 
  %BOOTSTRAP CRITICAL VALUE
  rng('default'); %reset seed
  boot=ceil(rand(n,brep)*n);
  Yb=Y(boot);
  Zb=Z(boot);
  Db=D(boot);
  for k = 1:brep
    [Ybs,t] = sort(Yb(:,k));
    Dbs = Db(:,k);
    Dbs = Dbs(t);
    Zbs = Zb(:,k);
    Zbs = Zbs(t);
    G0b = KaplanMeier(y0,Ybs,Dbs);
    bbhat = RCLAD(Ybs,Dbs,Zbs,bhat);
    if G0b<1e-6; G0b = 1e-6; end;
    if qopt==0
      TCSb(k) = quad(@(u) (bbhat*chen02cens_sorted(u,Ybs,Zbs,Dbs,y0,G0b,u)-bhat*chen02cens_sorted(u,Ys,Zs,Ds,y0,G0,u)).^2,-range,range,1e-3);
    elseif qopt==1
      TCSb(k) = mean((bbhat*chen02cens_sorted(u,Ybs,Zbs,Dbs,y0,G0b,u)-Lhat).^2)*2*range;
    elseif qopt==2
      TCSb(k) = integral(@(u) (bbhat*chen02cens_sorted(u,Ybs,Zbs,Dbs,y0,G0b,u)-bhat*chen02cens_sorted(u,Ys,Zs,Ds,y0,G0,u)).^2,-range,range,'AbsTol',1e-3);
    end    		 
  end
  %%%%%%%%%%%%%%%%%%%%%%%%%
  Tres(i,:) = [(TCS<prctile(TCSb,90)) (TCS<prctile(TCSb,95)) (TCS<prctile(TCSb,99))];
  time(i)=toc;
end  

mccs = [batch mc range qopt nq opt uopt brep mean(Tres) mean(time) mean(1-D)];

name = sprintf('~/TRANSF/MC/MCCScensbootbs%d.mat',n);
if exist(name,'file')
  load(name);
  MC = [MC; mccs];
else
  MC = mccs;
end
save(name,'MC')
