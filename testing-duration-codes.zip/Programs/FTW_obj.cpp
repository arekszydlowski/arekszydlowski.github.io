#include <stdlib.h>
#include <iostream>
#include <algorithm>
#include <math.h>
#include "mex.h"
#include <gsl/gsl_cdf.h>    
//#include<boost>
using namespace std;

extern void _main();

void mexFunction(
    int nlhs, mxArray *plhs[],
    int nrhs, const mxArray *prhs[])
{ double *ydata, *index, ym, ystd, wopt, gam, *Gamma, w1, w2;
  int sgn1, sgn2;
  mwSize n, cols;
  if (nrhs<6)
   mexErrMsgIdAndTxt("MATLAB:FTW:invalidNumInputs", "Six inputs required.");
   ydata = mxGetPr(prhs[0]); //get the pointer to the Y vector
   index = mxGetPr(prhs[1]); //get the pointer to the vector of indices
   wopt =  mxGetScalar(prhs[2]); //get the weight option
   ym =  mxGetScalar(prhs[3]); //get the mean of Y
   ystd =  mxGetScalar(prhs[4]); //get the std. dev. of Y
   gam = mxGetScalar(prhs[5]); //get the candidate gamma
   n = mxGetM(prhs[0]);  /*get the sizes of the arguments*/
   cols = mxGetN(prhs[0]);
   plhs[0] = mxCreateDoubleScalar(0);
   Gamma = mxGetPr(plhs[0]); //get the pointer to the output
  if (cols!=1)
   mexErrMsgIdAndTxt("MATLAB:FTW", "The first two arguments should be column vectors."); 
  if (wopt==0){ //normal weights
  for (int i=0; i<n; i++){ //loop over observations
    for (int ii=0; ii<n-1 ; ii++){ //another loop over the observations
      for (int iii=ii+1; iii<n ; iii++){ //another loop over the observations
	if (ii!=i && iii!=i){
	  if (gam>0){
	    w1 = 1+gam*((pow(*(ydata+ii),gam)-1)/gam-*(index+ii)+*(index+i));
	    w2 = 1+gam*((pow(*(ydata+iii),gam)-1)/gam-*(index+iii)+*(index+i));
	    sgn1 = (w1 > 0);
	    sgn2 = (w2 > 0);
	    if (sgn1*sgn2){
	    *Gamma += gsl_cdf_gaussian_Q(*(ydata+i)-ym,ystd) 
	      - gsl_cdf_gaussian_Q(max(*(ydata+i),pow(w1,1/gam))-ym,ystd)
	      - gsl_cdf_gaussian_Q(max(*(ydata+i),pow(w2,1/gam))-ym,ystd)
	      + gsl_cdf_gaussian_Q(max(pow(w1,1/gam),pow(w2,1/gam))-ym,ystd); 
	    }
	    else if (sgn1==0 && sgn2==1){
	    *Gamma += - gsl_cdf_gaussian_Q(max(*(ydata+i),pow(w2,1/gam))-ym,ystd)
	      + gsl_cdf_gaussian_Q(pow(w2,1/gam)-ym,ystd); 
	    }
	    else if (sgn1==1 && sgn2==0) {
	    *Gamma += - gsl_cdf_gaussian_Q(max(*(ydata+i),pow(w1,1/gam))-ym,ystd)
	      + gsl_cdf_gaussian_Q(pow(w1,1/gam)-ym,ystd); 
	    }
	    else {
	    *Gamma += - gsl_cdf_gaussian_Q(*(ydata+i)-ym,ystd) + 1;
	    }
	  }
	  else if (gam<0){
	    w1 = 1+gam*((pow(*(ydata+ii),gam)-1)/gam-*(index+ii)+*(index+i));
	    w2 = 1+gam*((pow(*(ydata+iii),gam)-1)/gam-*(index+iii)+*(index+i));
	    sgn1 = (w1 > 0);
	    sgn2 = (w2 > 0);
	    if (sgn1*sgn2) {
	    *Gamma += gsl_cdf_gaussian_Q(*(ydata+i)-ym,ystd) 
	      - gsl_cdf_gaussian_Q(max(*(ydata+i),pow(w1,1/gam))-ym,ystd)
	      - gsl_cdf_gaussian_Q(max(*(ydata+i),pow(w2,1/gam))-ym,ystd)
	      + gsl_cdf_gaussian_Q(max(pow(w1,1/gam),pow(w2,1/gam))-ym,ystd);
	      }
	    else if (sgn1==0 && sgn2==1) {
	    *Gamma += gsl_cdf_gaussian_Q(*(ydata+i)-ym,ystd) 
	      - gsl_cdf_gaussian_Q(max(*(ydata+i),pow(w2,1/gam))-ym,ystd);
	    } 
	    else if (sgn1==1 && sgn2==0) {
	    *Gamma += gsl_cdf_gaussian_Q(*(ydata+i)-ym,ystd) 
	      - gsl_cdf_gaussian_Q(max(*(ydata+i),pow(w1,1/gam))-ym,ystd);
	    } 
	    else {
	    *Gamma += gsl_cdf_gaussian_Q(*(ydata+i)-ym,ystd);
	    } 
	  }
	  else {
	    *Gamma += gsl_cdf_gaussian_Q(*(ydata+i)-ym,ystd) 
	      - gsl_cdf_gaussian_Q(max(*(ydata+i),*(ydata+ii)*exp(-*(index+ii)+*(index+i)))-ym,ystd)
	      - gsl_cdf_gaussian_Q(max(*(ydata+i),*(ydata+iii)*exp(-*(index+iii)+*(index+i)))-ym,ystd)
	      + gsl_cdf_gaussian_Q(max(*(ydata+ii)*exp(-*(index+ii)+*(index+i)),*(ydata+iii)*exp(-*(index+iii)+*(index+i)))-ym,ystd); 
	  }
	  }
	}
      }
    }
  }
 else if (wopt==1){ //logistic weights
  for (int i=0; i<n; i++){ //loop over observations
    for (int ii=0; ii<n-1 ; ii++){ //another loop over the observations
      for (int iii=ii+1; iii<n ; iii++){ //another loop over the observations
	if (ii!=i && iii!=i){
	  if (gam>0){
	    w1 = 1+gam*((pow(*(ydata+ii),gam)-1)/gam-*(index+ii)+*(index+i));
	    w2 = 1+gam*((pow(*(ydata+iii),gam)-1)/gam-*(index+iii)+*(index+i));
	    sgn1 = (w1 > 0);
	    sgn2 = (w2 > 0);
	    if (sgn1*sgn2){
	    *Gamma += gsl_cdf_logistic_Q(*(ydata+i)-ym,ystd) 
	      - gsl_cdf_logistic_Q(max(*(ydata+i),pow(w1,1/gam))-ym,ystd)
	      - gsl_cdf_logistic_Q(max(*(ydata+i),pow(w2,1/gam))-ym,ystd)
	      + gsl_cdf_logistic_Q(max(pow(w1,1/gam),pow(w2,1/gam))-ym,ystd); 
	    }
	    else if (sgn1==0 && sgn2==1){
	    *Gamma += - gsl_cdf_logistic_Q(max(*(ydata+i),pow(w2,1/gam))-ym,ystd)
	      + gsl_cdf_logistic_Q(pow(w2,1/gam)-ym,ystd); 
	    }
	    else if (sgn1==1 && sgn2==0) {
	    *Gamma += - gsl_cdf_logistic_Q(max(*(ydata+i),pow(w1,1/gam))-ym,ystd)
	      + gsl_cdf_logistic_Q(pow(w1,1/gam)-ym,ystd); 
	    }
	    else {
	    *Gamma += - gsl_cdf_logistic_Q(*(ydata+i)-ym,ystd) + 1;
	    }
	  }
	  else if (gam<0){
	    w1 = 1+gam*((pow(*(ydata+ii),gam)-1)/gam-*(index+ii)+*(index+i));
	    w2 = 1+gam*((pow(*(ydata+iii),gam)-1)/gam-*(index+iii)+*(index+i));
	    sgn1 = (w1 > 0);
	    sgn2 = (w2 > 0);
	    if (sgn1*sgn2) {
	    *Gamma += gsl_cdf_logistic_Q(*(ydata+i)-ym,ystd) 
	      - gsl_cdf_logistic_Q(max(*(ydata+i),pow(w1,1/gam))-ym,ystd)
	      - gsl_cdf_logistic_Q(max(*(ydata+i),pow(w2,1/gam))-ym,ystd)
	      + gsl_cdf_logistic_Q(max(pow(w1,1/gam),pow(w2,1/gam))-ym,ystd);
	      }
	    else if (sgn1==0 && sgn2==1) {
	    *Gamma += gsl_cdf_logistic_Q(*(ydata+i)-ym,ystd) 
	      - gsl_cdf_logistic_Q(max(*(ydata+i),pow(w2,1/gam))-ym,ystd);
	    } 
	    else if (sgn1==1 && sgn2==0) {
	    *Gamma += gsl_cdf_logistic_Q(*(ydata+i)-ym,ystd) 
	      - gsl_cdf_logistic_Q(max(*(ydata+i),pow(w1,1/gam))-ym,ystd);
	    } 
	    else {
	    *Gamma += gsl_cdf_logistic_Q(*(ydata+i)-ym,ystd);
	    } 
	  }
	  else {
	    *Gamma += gsl_cdf_logistic_Q(*(ydata+i)-ym,ystd) 
	      - gsl_cdf_logistic_Q(max(*(ydata+i),*(ydata+ii)*exp(-*(index+ii)+*(index+i)))-ym,ystd)
	      - gsl_cdf_logistic_Q(max(*(ydata+i),*(ydata+iii)*exp(-*(index+iii)+*(index+i)))-ym,ystd)
	      + gsl_cdf_logistic_Q(max(*(ydata+ii)*exp(-*(index+ii)+*(index+i)),*(ydata+iii)*exp(-*(index+iii)+*(index+i)))-ym,ystd); 
	  }
	  }
	}
      }
    }
  }
  *Gamma /= n*(n-1)*(n-2);
  return;
}

