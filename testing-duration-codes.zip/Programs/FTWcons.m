function [c,ceq] = FTWcons(Y,X,par)

% function [c,ceq] = FTWcons(Y,X)
% contstraint for the Foster, Tian, Wei (01) estimator
% par - (p+1) x 1 column vector
%       par(1) - Box-Cox parameter
%       par(2:end) - p x 1 column vector of regression coefficients
%Copyright: Arkadiusz Szydlowski

c = [];
ceq = X'*(boxcox(par(1),Y)-X*par(2:end));

