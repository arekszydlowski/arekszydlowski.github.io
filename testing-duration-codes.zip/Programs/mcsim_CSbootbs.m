function mcsim_CSbootbs(batch,mc,n,range,qopt,nq,opt,uopt,brep)

% MC simulations with bootstrap critical value
% mc - # of MC simulations
% n - sample size
% range - defines the range of y values: [-range, range]; range = 2 or 3
% qopt - integration option
%     qopt=0 MATLAB quad
%     qopt=1 MC integration
%     qopt=2 MATLAB integral
% opt - test option
%     opt=0 true model: T(y)=y
%     opt=1 true model: T(y)=log(y+b)-log(b)
%     opt=2 true model: T(y)=1/13 sinh(2y) 
% uopt - error distribution option
%     uopt=0 normal(0,1) 
%     uopt=1 extreme value type 1 (Cox model) 
%     uopt=2 logistic (MPH model with extreme value type I unobserved heterogeneity)
% nq - number of points in MC integration
%Copyright: Arkadiusz Szydlowski

if (ischar(batch)), batch=str2num(batch); end;
if (ischar(mc)), mc=str2num(mc); end;
if (ischar(n)), n=str2num(n); end;
if (ischar(range)), range=str2num(range); end;
if (ischar(qopt)), qopt=str2num(qopt); end;
if (ischar(nq)), nq=str2num(nq); end;
if (ischar(opt)), opt=str2num(opt); end;
if (ischar(uopt)), uopt=str2num(uopt); end;
if (ischar(brep)), brep=str2num(brep); end;

seedname=sprintf('seedCS%d_%d.mat',n,batch);
if exist(seedname,'file')~=0
  load(seedname);
else
  rng('shuffle');
  seed = rng;
  name = sprintf('seedCS%d_%d.mat',n,batch);
  save(name,'seed');
end

y0 = 0; %normalization point

if range==2
  b = 2.1167;
elseif range==3
  b = 3.0267;
end 

TCSb = zeros(1,brep);
Tres = zeros(mc,3);
time = zeros(mc,1);

%drawing points for MC integration
rng('default');
u=-range+2*range*rand(nq,1);

for i=1:mc
  rng(seed); 
  tic;
  Z=randn(n,1);
  if uopt==0
      U=randn(n,1);
  elseif uopt==1
      U=evrnd(0,1,[n 1]);
  elseif uopt==1.5
      U=evrnd(0.57721566490153,1,[n 1]);
  elseif uopt==2
      unif = rand(n,1);
      U = log(unif./(1-unif));
  end

  if opt==0
      Y = Z + U;
  elseif opt==1
      Y = b*exp(Z + U) - b;
  elseif opt==2
      Y = 0.5*asinh(13*(Z+U));
  elseif opt==10
      Y = 2*Z + U;
  end

%calculate the OLS estimator
bhat = Z'*Y/(Z'*Z);

  if qopt==0
    TCS = quad(@(u) (bhat*chen02_sorted(u,Y,Z,y0,u)-u).^2,-range,range,1e-3);
  elseif qopt==1
    Lhat = bhat*chen02_sorted(u,Y,Z,y0,u);
    TCS = mean((Lhat-u).^2)*2*range;
  elseif qopt==2
    TCS = integral(@(u) (bhat*chen02_sorted(u,Y,Z,y0,u)-u).^2,-range,range,'AbsTol',1e-3);
  end
  seed = rng; %store seed for generating next MC draws
  		 
  %BOOTSTRAP CRITICAL VALUE
  rng('default'); %reset seed
  boot=ceil(rand(n,brep)*n);
  Yb=Y(boot);
  Zb=Z(boot);
  for k = 1:brep
    bbhat = Zb(:,k)'*Yb(:,k)/(Zb(:,k)'*Zb(:,k));
    if qopt==0
      TCSb(k) = quad(@(u) (bbhat*chen02_sorted(u,Yb(:,k),Zb(:,k),y0,u)-bhat*chen02_sorted(u,Y,Z,y0,u)).^2,-range,range,1e-3);
    elseif qopt==1
      TCSb(k) = mean((bbhat*chen02_sorted(u,Yb(:,k),Zb(:,k),y0,u)-Lhat).^2)*2*range;
    elseif qopt==2
      TCSb(k) = integral(@(u) (bbhat*chen02_sorted(u,Yb(:,k),Zb(:,k),y0,u)-bhat*chen02_sorted(u,Y,Z,y0,u)).^2,-range,range,'AbsTol',1e-3);
    end    		 
  end
  %%%%%%%%%%%%%%%%%%%%%%%%%
  Tres(i,:) = [(TCS<prctile(TCSb,90)) (TCS<prctile(TCSb,95)) (TCS<prctile(TCSb,99))];
  time(i)=toc;
end  

mccs = [batch mc range qopt nq opt uopt brep mean(Tres) mean(time)];

name = sprintf('~/TRANSF/MC/MCCSbootbs%d.mat',n);
if exist(name,'file')
  load(name);
  MC = [MC; mccs];
else
  MC = mccs;
end
save(name,'MC')
