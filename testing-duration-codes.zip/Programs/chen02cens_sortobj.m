function Gamma  = chen02cens_sortobj(Y,X,D,s,y0,G0,l) 

%Copyright: Arkadiusz Szydlowski

n = length(Y);
Zstar = [X; X+l];
[Zstar,t] = sort(Zstar);
G = KaplanMeier(s,Y,D);
if G<1e-6; G = 1e-6; end;
Dstar = [(Y>=s)/G; (Y>=y0)/G0];
Dstar = Dstar(t);
Gamma = [1:2*n]*Dstar;