function KM = KaplanMeier(y,Y,D)

% Kaplan-Meier estimator of the censoring's survival function at y 
% Note: (i) only single exit at a time (continuous durations)
%       (ii) (Y,D) need to be sorted in ascending order of Y
% Y - observed duration
% D - censoring indicator, D=(Y<=C)
%Copyright: Arkadiusz Szydlowski

n = size(Y,1);
I = max(find(Y<=y));
DI = D(1:I);

N = ~DI;
R = n - [0:I-1]';
KM = prod(1-N./R);
