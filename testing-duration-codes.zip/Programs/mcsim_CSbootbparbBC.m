function mcsim_CSbootbparbBC(batch,mc,n,range,qopt,nq,opt,uopt,brep)

% MC simulations with bootstrap critical value for Box-Cox
% mc - # of MC simulations
% n - sample size
% range - defines the range of y values: [-range, range]; range = 2 or 3
% qopt - integration option
%     qopt=0 MATLAB quad
%     qopt=1 MC integration
%     qopt=2 MATLAB integral
% opt - test option
%     opt=0 true model: T(y)=log(y)
%     opt=1 true model: T(y)=4(y^0.25-1)
%     opt=2 true model: T(y)=1/13 sinh(2log(y)) 
% uopt - error distribution option
%     uopt=0 normal(0,1) 
%     uopt=1 extreme value type 1 (Cox model) 
%     uopt=2 logistic (MPH model with extreme value type I unobserved heterogeneity)
% nq - number of points in MC integration 

warning off all

seedname=sprintf('seedCS%d_%d_%d.mat',mc,n,batch);
if exist(seedname,'file')~=0
  load(seedname);
else
  rng('shuffle');
  seed = rng;
  name = sprintf('seedCS%d_%d_%d.mat',mc,n,batch);
  save(name,'seed');
end

y0 = 1; %normalization point

TCSb = zeros(1,brep);
Tres = zeros(mc,3);
time = zeros(mc,1);

%drawing points for MC integration
rng('default');
u=0.1+range*rand(nq,1);

for i=1:mc
  rng(seed); 
  tic;
  Z=randn(n,1);
  if uopt==0
    U=randn(n,1);
  elseif uopt==1
    U=evrnd(0,1,[n 1]);
  elseif uopt==2
    unif = rand(n,1);
    U = log(unif./(1-unif));
  end

  if opt==0
    Y = exp(Z + U);
  elseif opt==1
    Y = (1 + 0.25*(Z + U)).^4;
  elseif opt==2
    Y = exp(0.5*asinh(13*(Z+U)));
  end

%calculate the FTW estimator
wopt = 0;
par = FTW(Y,Z,wopt);
ghat = par(1);
bhat = par(2);
ehat = boxcox(ghat,Y) - Z*bhat;

  if qopt==0
    TCS = quad(@(u) (bhat*chen02_sorted(u,Y,Z,y0,u)-boxcox(ghat,u)).^2,0.1,range,1e-3);
  elseif qopt==1
    Lhat = bhat*chen02_sorted(u,Y,Z,y0,u);
    BChat = boxcox(ghat,u);
    TCS = mean((Lhat-BChat).^2)*range;
  elseif qopt==2
    TCS = integral(@(u) (bhat*chen02_sorted(u,Y,Z,y0,u)-boxcox(ghat,u)).^2,0.1,range,'AbsTol',1e-3);
  end
  seed = rng; %store seed for generating next MC draws
  		 
  %BOOTSTRAP CRITICAL VALUE
  rng('default'); %reset seed
  boot=ceil(rand(n,brep)*n);
  eb = ehat(boot);
  if ghat ~= 0 
    Yb = ((repmat(Z*bhat,1,brep) + eb)*ghat + 1).^(1/ghat);
    Yb = (imag(Yb)==0).*Yb + (1-(imag(Yb)==0))*0.00001;
    Yb = max(Yb, 0.00001);
  else
    Yb = exp(repmat(Z*bhat,1,brep) + eb);  
  end
  for k = 1:brep
    parb = FTW(Yb(:,k),Z,wopt);
    bghat = parb(1);
    bbhat = parb(2);
    if qopt==0
      TCSb(k) = quad(@(u) (bbhat*chen02_sorted(u,Yb(:,k),Z,y0,u)...
          - boxcox(bghat,u)).^2,0.1,range,1e-3);
    elseif qopt==1
      TCSb(k) = mean((bbhat*chen02_sorted(u,Yb(:,k),Z,y0,u)...
          - boxcox(bghat,u)).^2)*range;
    elseif qopt==2
      TCSb(k) = integral(@(u) (bbhat*chen02_sorted(u,Yb(:,k),Z,y0,u)...
          - boxcox(bghat,u)).^2,0.1,range,'AbsTol',1e-3);
    end    		 
  end
  %%%%%%%%%%%%%%%%%%%%%%%%%
  Tres(i,:) = [(TCS<prctile(TCSb,90)) (TCS<prctile(TCSb,95)) (TCS<prctile(TCSb,99))];
  time(i)=toc;
end  

mccs = [batch mc range qopt nq opt uopt brep mean(Tres,1) mean(time) TCS TCSb];

name = sprintf('~/TRANSF/MC/MCCSbootbsparbBC%d.mat',n);
if exist(name,'file')
  load(name);
  MC = [MC; mccs];
else
  MC = mccs;
end
save(name,'MC')
